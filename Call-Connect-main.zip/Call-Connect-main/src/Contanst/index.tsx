const APP_DEFINE = {
  APP_NAME: "APP NAME",
};

export { APP_DEFINE };
