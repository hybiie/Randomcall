const images = {
  loginBg: require("./images/login_bg.png"),
  logo: require("./images/logo.png"),
  ic_google: require("./images/ic_google.png"),
};

export { images };
